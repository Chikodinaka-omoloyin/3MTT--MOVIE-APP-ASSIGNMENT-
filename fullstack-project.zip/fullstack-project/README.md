
# Fullstack Login/Register App

## 🧩 Tech Stack
- Frontend: React
- Backend: Node.js + Express

## 🚀 How to Run

### Backend
1. Navigate to `backend/`
2. Run `npm install express cors`
3. Run `node server.js`

### Frontend
1. Navigate to `frontend/`
2. Run `npm install`
3. Run `npm start`

Make sure backend is running on port 5000.

## ✅ Features
- Simple login/register
- No database (uses memory for demo)
- Switch between login and register forms

