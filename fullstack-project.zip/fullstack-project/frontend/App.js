
import React, { useState } from 'react';

function App() {
  const [page, setPage] = useState('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleAuth = async (type) => {
    const res = await fetch(`http://localhost:5000/api/${type}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json();
    setMessage(data.message);
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>{page === 'login' ? 'Login' : 'Register'}</h1>
      <input placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} /><br />
      <input placeholder="Password" type="password" value={password} onChange={e => setPassword(e.target.value)} /><br />
      <button onClick={() => handleAuth(page)}>{page}</button>
      <p>{message}</p>
      <button onClick={() => setPage(page === 'login' ? 'register' : 'login')}>
        Switch to {page === 'login' ? 'Register' : 'Login'}
      </button>
    </div>
  );
}

export default App;
